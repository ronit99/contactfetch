//
//  ViewController.swift
//  contactfetch
//
//  Created by Romit Patel on 28/05/19.
//  Copyright © 2019 Romit Patel. All rights reserved.
//

import UIKit
import Foundation
import ContactsUI
class ViewController: UIViewController {
    var contcarray = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.callconts()
    }
 
    func callconts()
    {
        let contactStore = CNContactStore()
        var contacts = [CNContact]()
        let keys = [
            CNContactFormatter.descriptorForRequiredKeys(for: .fullName),
            CNContactPhoneNumbersKey,
            CNContactEmailAddressesKey
            ] as [Any]
        let request = CNContactFetchRequest(keysToFetch: keys as! [CNKeyDescriptor])
        do {
            try contactStore.enumerateContacts(with: request){
                (contact, stop) in
                // Array containing all unified contacts from everywhere
                contacts.append(contact)
                for phoneNumber in contact.phoneNumbers {
                    if let number = phoneNumber.value as? CNPhoneNumber, let label = phoneNumber.label {
                        let localizedLabel = CNLabeledValue<CNPhoneNumber>.localizedString(forLabel: label)
                        print("\(contact.givenName) -- \(number.stringValue)")
                        self.contcarray.append("Name: \(contact.givenName) No: \(number.stringValue)")
//                         print("\(contact.givenName) \(contact.familyName) tel:\(localizedLabel) -- \(number.stringValue), email: \(contact.emailAddresses)")
                    }
                }
                
                
            }
            print(contcarray)
        } catch {
            print("unable to fetch contacts")
        }
    }

}

